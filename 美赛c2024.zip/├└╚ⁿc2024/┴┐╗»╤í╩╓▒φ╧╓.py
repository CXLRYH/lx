import pandas as pd

# 加载数据
file_path = 'C:\\Users\shuoz\Desktop/momentum_diff.csv'  # 请确保路径与文件名匹配
data = pd.read_csv(file_path, header=None)
data.columns = ['Time', 'Performance Difference']

# 清理数据：转换数据类型并移除可能的错误行
data_corrected = data.iloc[1:].copy()  # 假设第一行是错误的输入，跳过它
data_corrected['Time'] = pd.to_numeric(data_corrected['Time'])
data_corrected['Performance Difference'] = pd.to_numeric(data_corrected['Performance Difference'])

# 计算表现差异的基本统计量
statistics_performance = data_corrected['Performance Difference'].describe()

# 确定好的动量状态阈值
good_momentum_threshold_performance = statistics_performance['75%']

# 识别具有较好动量状态的时间点
good_momentum_times = data_corrected[data_corrected['Performance Difference'] > good_momentum_threshold_performance]['Time']

# 输出结果
print(f"基本统计量:\n{statistics_performance}\n")
print(f"好的动量状态阈值: {good_momentum_threshold_performance}\n")
print(f"具有较好动量状态的时间点: {good_momentum_times.tolist()}")