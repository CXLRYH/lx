import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random

# 读取数据
file_path = "C:\\Users\shuoz\Desktop\数据csv\Christopher Eubanks.CSV"
df = pd.read_csv(file_path)

dpi = 300
def detect_consecutive_scores(score_diff_series):
    consecutive_start = []
    current_direction = 0
    for i in range(1, len(score_diff_series)):
        diff = score_diff_series[i] - score_diff_series[i-1]
        if diff > 0:
            if current_direction != 1:
                consecutive_start.append(i)
                current_direction = 1
        elif diff < 0:
            if current_direction != -1:
                consecutive_start.append(i)
                current_direction = -1
        else:
            current_direction = 0
    return consecutive_start

# 定义适应度函数
def fitness_function(params):
    global df  # 使用全局数据框架

    momentum_player1, momentum_player2 = 0, 0
    correct_predictions = 0
    total_predictions = 0
    loss = 0  # 用于计算交叉熵损失
    momentum_changes_player1 = []  # 存储选手1的动量变化
    momentum_changes_player2 = []  # 存储选手2的动量变化

    consecutive_wins = 0  # 连续得分计数器
    consecutive_losses = 0  # 连续失分计数器

    for _, row in df.iterrows():
        p1_score = row['p1_score']
        p2_score = row['p2_score']

        # 处理 'AD' 情况
        if p1_score == 'AD':
            p1_score = 45
        elif p2_score == 'AD':
            p2_score = 45



        p2_net_pt = row['p2_net_pt']
        p2_net_pt_won = row['p2_net_pt_won']
        point_victor = row['point_victor']

        p1_games = row['p1_games']
        p2_games = row['p2_games']
        server = row['server']
        rally_count = row['rally_count']
        p1_winner = row['p1_winner']
        p1_break_pt = row['p1_break_pt']

        # 生成参数
        [a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v ] = params

        # 这里应用动量更新逻辑
        # 计算每个点后的动量
        # 示例：如果 point_victor 是 1，player1 赢得了这个点
        if point_victor == 1:
            consecutive_wins += 1
            consecutive_losses = 0  # 重置连续失分计数器
        elif point_victor == 2:
            consecutive_losses += 1
            consecutive_wins = 0  # 重置连续得分计数器
        else:
            consecutive_wins = 0  # 重置连续得分计数器
            consecutive_losses = 0  # 重置连续失分计数器
        if consecutive_wins ==2:
            momentum_player2 += b  # 连续两次失分时减少动量
        if consecutive_losses ==2:
            momentum_player1 += a
        if consecutive_wins ==3:
            momentum_player1 += c
                                     # 连续三次得分时增加动量
        if consecutive_losses ==3:
            momentum_player2 += d

        if server == 1:
            momentum_player1 += e

        elif server == 2:
            momentum_player2 += f
        if server == 1 and rally_count == 0 and point_victor==1:
            momentum_player1 -= g
        elif server == 2 and rally_count == 0 and point_victor==1:

            momentum_player2 -= h

        # 处理发球得分
        if server == 1 and rally_count == 0:
            momentum_player1 += i

        elif server == 2 and rally_count == 0:
            momentum_player2 += j

        # 处理破发球得分
        if server == 1 and p1_break_pt == 2:
            momentum_player2 += k
        elif server == 2 and p1_break_pt == 1:
            momentum_player1 += l

        # 获得局点球
        if p1_score == 45 and p2_score <= '40':
            momentum_player1 += m
        elif p1_score <= '40' and p2_score == 45:  # 注意 'AD' 已被转换为 45
            momentum_player2 += n
        # 不可触摸球
        if p1_winner == 1:
            momentum_player1 += o
        elif p1_winner == 2:
            momentum_player2 += p
        if p2_net_pt == 1 and p2_net_pt_won == 1:
            momentum_player1 += q
        if p2_net_pt == 1 and p2_net_pt_won == 0:
            momentum_player2 += r  # 一方定位于球网附近时
        # 考虑盘数差较大时的影响
        if int(p1_games) - int(p2_games) >= 2:
            momentum_player1 += s
        elif int(p2_games) - int(p1_games) >= 2:
            momentum_player2 += t
        # 如果盘数追平
        if int(p1_games) == int(p2_games) and point_victor == 1:
            momentum_player1 += u
        elif int(p2_games) == int(p1_games)and point_victor == 2:
            momentum_player2 += v

        momentum_changes_player1.append(momentum_player1)
        momentum_changes_player2.append(momentum_player2)

        # 计算概率并计算交叉熵损失
        momentum_sum = abs(momentum_player1) + abs(momentum_player2)
        if momentum_sum > 0:  # 防止除以0
            p1_prob = abs(momentum_player1) / momentum_sum
            p2_prob = abs(momentum_player2) / momentum_sum

            # 计算交叉熵损失
            if point_victor == 1:
                loss -= np.log(p1_prob)
            elif point_victor == 2:
                epsilon = 1e-10  # 一个小常数
                p2_prob = np.clip(p2_prob, epsilon, 1. - epsilon)  # 将概率限制在[epsilon, 1-epsilon]之间
                loss -= np.log(p2_prob)

        # 计算预测准确率
        if p1_prob > p2_prob:
            predicted_winner = 1
        else:
            predicted_winner = 2

        if predicted_winner == row['point_victor']:
            correct_predictions += 1
        total_predictions += 1

    # 返回准确率作为适应度值和交叉熵损失
    accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
    return accuracy, loss, momentum_changes_player1, momentum_changes_player2

# 示例参数使用
population_size = 50
parameters_population = []

for _ in range(population_size):
    a = np.random.uniform(5, 10)
    b = np.random.uniform(5, 10)
    c = np.random.uniform(10, 20)
    d = np.random.uniform(10, 20)
    e = np.random.uniform(10, 20)
    f = np.random.uniform(10, 20)
    g = np.random.uniform(5, 10)
    h = np.random.uniform(5, 10)
    i = np.random.uniform(10, 20)
    j = np.random.uniform(10, 20)
    k = np.random.uniform(20, 30)
    l = np.random.uniform(20, 30)
    m = np.random.uniform(10, 20)
    n = np.random.uniform(10, 20)
    o = np.random.uniform(10, 20)
    p = np.random.uniform(10, 20)
    q = np.random.uniform(5, 10)
    r = np.random.uniform(5, 10)
    s = np.random.uniform(0, 5)
    t = np.random.uniform(0, 5)
    u = np.random.uniform(10, 20)
    v = np.random.uniform(10, 20)



    params = [a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t,u,v]
    parameters_population.append(params)

# 遗传算法参数
generations = 10
selection_rate = 0.1
mutation_rate = 0.1

best_fitness_scores = []
best_losses = []

for generation in range(generations):
    fitness_results = [fitness_function(params) for params in parameters_population]
    fitness_scores = [result[0] for result in fitness_results]
    losses = [result[1] for result in fitness_results]

    # 选择
    selected_indices = np.argsort(fitness_scores)[-int(selection_rate * population_size):]
    selected_population = [np.array(parameters_population)[i] for i in selected_indices]

    best_fitness_scores.append(max(fitness_scores))
    best_losses.append(min(losses))

    # 交叉和变异
    new_population = []
    while len(new_population) < population_size:
        parent1, parent2 = random.sample(selected_population, 2)
        crossover_point = random.randint(1, len(parent1) - 1)
        child1 = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
        child2 = np.concatenate([parent2[:crossover_point], parent1[crossover_point:]])

        # 变异
        for child in [child1, child2]:
            if random.random() < mutation_rate:
                mutate_index = random.randint(0, len(child) - 1)
                child[mutate_index] = np.random.rand()

        new_population.extend([child1, child2])

    parameters_population = new_population  # 更新种群

# 输出最优解
best_index = np.argmax(best_fitness_scores)
best_parameters = parameters_population[best_index]
final_accuracy, final_loss, momentum_changes_player1, momentum_changes_player2 = fitness_function(best_parameters)
print("Best Parameters:", best_parameters)
print("best_fitness_scores:", max(best_fitness_scores))
print("Final Loss:", final_loss)

# 绘制适应度图像
momentum_diff = np.array(momentum_changes_player1) - np.array(momentum_changes_player2)
momentum_changes_data_player1 = pd.DataFrame({'Momentum Change Player 1': momentum_changes_player1})
momentum_changes_data_player2 = pd.DataFrame({'Momentum Change Player 2': momentum_changes_player2})
momentum_diff=pd.DataFrame({'momentum_diff.csv': momentum_diff})
momentum_changes_data_player1.to_csv('momentum_changes_player1.csv', index=False)
momentum_changes_data_player2.to_csv('momentum_changes_player2.csv', index=False)
momentum_diff.to_csv('momentum_diff',index=False)
# 绘制适应度图像

plt.figure(figsize=(12, 5), dpi=dpi)
plt.plot([float(score) for score in best_fitness_scores], linewidth=2, marker='o')
plt.xlabel('Generation', fontsize=14)
plt.ylabel('Best Fitness Score', fontsize=14)
plt.title('Best Fitness Score', fontsize=16)
plt.savefig('best_fitness.pdf', format='pdf', dpi=dpi, bbox_inches='tight')
plt.show()

# 绘制损失图像并保存为 best_loss.pdf
plt.figure(figsize=(12, 5), dpi=dpi)
plt.plot([float(loss) for loss in best_losses], linewidth=2, marker='o')
plt.xlabel('Generation', fontsize=14)
plt.ylabel('Loss', fontsize=14)
plt.title('Loss', fontsize=16)
plt.savefig('best_loss.pdf', format='pdf', dpi=dpi, bbox_inches='tight')
plt.show()

# 生成动量变化图并保存为 momentum_change.pdf
plt.figure(figsize=(12, 5), dpi=dpi)
plt.plot(momentum_changes_player1, label='player1', linewidth=2)
plt.plot(momentum_changes_player2, label='Player2', linewidth=2)
plt.xlabel('Point', fontsize=14)
plt.ylabel('Momentum Change', fontsize=14)
plt.legend(fontsize=12)
plt.title('Momentum Change Over Points', fontsize=16)
plt.savefig('momentum_change.pdf', format='pdf', dpi=dpi, bbox_inches='tight')
plt.show()

# 生成动量差值变化图并保存为 momentum_difference.pdf
plt.figure(figsize=(12, 5), dpi=dpi)
plt.plot(momentum_diff, label='player1 - Player2', linewidth=2)
plt.xlabel('Point', fontsize=14)
plt.ylabel('Momentum Difference', fontsize=14)
plt.legend(fontsize=12)
plt.title('Momentum Difference Over Points', fontsize=16)
plt.savefig('momentum_difference.pdf', format='pdf', dpi=dpi, bbox_inches='tight')
plt.show()

