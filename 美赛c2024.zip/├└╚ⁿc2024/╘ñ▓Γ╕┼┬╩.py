import pandas as pd
import matplotlib.pyplot as plt

# 加载数据
df = pd.read_csv('/mnt/data/Wimbledon_featured_matches.csv')


# 定义动量动态指标函数
def calculate_momentum(df):
    df['p1_momentum'] = 0
    df['p2_momentum'] = 0
    last_point_winner = None

    for i, row in df.iterrows():
        momentum_change = 1





             # 处理 'AD' 情况
        if p1_score == 'AD':
                    p1_score = 45
        elif p2_score == 'AD':
                    p2_score = 45

                serve_width = row['serve_width']
                serve_depth = row['serve_depth']
                return_depth = row['return_depth']
                winner_shot_type = row['winner_shot_type']
                p2_net_pt = row['p2_net_pt']
                p2_net_pt_won = row['p2_net_pt_won']
                point_victor = row['point_victor']
                game_victor = row['game_victor']
                set_victor = row['set_victor']
                p1_games = row['p1_games']
                p2_games = row['p2_games']
                server = row['server']
                rally_count = row['rally_count']
                p1_winner = row['p1_winner']
                p1_break_pt = row['p1_break_pt']



                # 这里应用动量更新逻辑
                # 计算每个点后的动量
                # 示例：如果 point_victor 是 1，player1 赢得了这个点
         if point_victor == 1:
                    momentum_change = 1 += a
        elif point_victor == 2:
                    momentum_player2 += b
                # 处理发球
        if server == 1:
                    momentum_player1 += c
        elif server == 2:
                    momentum_player2 += d
                # 处理发球得分
        if server == 1 and rally_count == 0:
                    momentum_player1 += e
        elif server == 2 and rally_count == 0:
                    momentum_player2 += f
                # 处理连续两次得分
        if p1_score == '30' and p2_score == '0' and point_victor == 1:
                    momentum_player1 += g
        elif p1_score == '0' and p2_score == '30' and point_victor == 2:
                    momentum_player2 += h
                # 处理破发球得分
        if (server == 1 and p1_break_pt == 2):
                    momentum_player2 += i
        elif (server == 2 and p1_break_pt == 1):
                    momentum_player1 += j
                # 处理连续两次丢分
        if p1_score == '0' and p2_score == '30' and point_victor == 2:
                    momentum_player1 -= k
        elif p1_score == '30' and p2_score == '0' and point_victor == 1:
                    momentum_player2 -= l
                # 处理丢失赛点球或局点球
        if p1_score == 45 and p2_score == '40':
                    momentum_player1 += m
        elif p1_score == '40' and p2_score == 45:  # 注意 'AD' 已被转换为 45
                    momentum_player2 += n
                # 处理发球失误
        if server == 1 and (serve_width != 'BW' or serve_depth != 'CTL'):
                    momentum_player1 -= o
        elif server == 2 and (serve_width != 'BW' or serve_depth != 'CTL'):
                    momentum_player2 -= p
                # 考虑球员习惯对得分击球数较多时的影响
        if p1_winner == 1:
                    momentum_player1 += q
        elif p1_winner == 2:
                    momentum_player2 += r  # 以“不可触摸”的击球赢得一分

        if p2_net_pt == 1 and p2_net_pt_won == 1:
                    momentum_player1 += u
        if p2_net_pt == 1 and p2_net_pt_won == 0:
                    momentum_player2 += v  # 一方定位于球网附近时
                # 考虑分差和盘数差较大时的影响
        if int(p1_score) - int(p2_score) >= 2 or int(p1_games) - int(p2_games) >= 2:
                    momentum_player1 += w
        elif int(p2_score) - int(p1_score) >= 2 or int(p2_games) - int(p1_games) >= 2:
                    momentum_player2 += x
                # 如果比分追平
        if p1_score == p2_score and point_victor == 1:
                    momentum_player1 += y
        elif p1_score == p2_score and point_victor == 2:
                    momentum_player2 += z
                # 计算概率并计算交叉熵损失
                momentum_sum = abs(momentum_player1) + abs(momentum_player2)

        if row['server'] == row['point_victor']:
            momentum_change = 1
        else:
            momentum_change = 3

        if last_point_winner == current_point_winner:
            momentum_change += 1

        if current_point_winner == 'p1':
            df.loc[i, 'p1_momentum'] += momentum_change
            df.loc[i, 'p2_momentum'] -= momentum_change
        else:
            df.loc[i, 'p1_momentum'] -= momentum_change
            df.loc[i, 'p2_momentum'] += momentum_change

        last_point_winner = current_point_winner

    return df


# 计算动量
momentum_df = calculate_momentum(df)

# 计算每局的动量总和
momentum_sums = momentum_df.groupby('game_no').agg({'p1_momentum': 'sum', 'p2_momentum': 'sum'}).reset_index()

# 计算胜率
momentum_sums['p1_win_probability'] = momentum_sums['p1_momentum'] / (
            momentum_sums['p1_momentum'] + momentum_sums['p2_momentum'])
momentum_sums['p2_win_probability'] = momentum_sums['p2_momentum'] / (
            momentum_sums['p1_momentum'] + momentum_sums['p2_momentum'])

# 初始化预测正确的计数器
correct_predictions = 0
total_predictions = 0

for i in range(1, len(momentum_sums)):
    current_game = momentum_sums.iloc[i - 1]
    next_game = momentum_sums.iloc[i]

    predicted_winner = 'p1' if current_game['p1_win_probability'] > current_game['p2_win_probability'] else 'p2'
    actual_winner = 'p1' if next_game['p1_momentum'] > next_game['p2_momentum'] else 'p2'

    if predicted_winner == actual_winner:
        correct_predictions += 1
    total_predictions += 1

# 计算预测正确率
accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0

print(f'预测正确率: {accuracy * 100:.2f}%')
