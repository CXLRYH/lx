import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random

# 读取数据
file_path = 'C:\\Users\shuoz\Desktop\数据/Frances Tiafoe.csv'
df = pd.read_csv(file_path)

# 定义适应度函数
def fitness_function(params):
    global df  # 使用全局数据框架
    momentum_player1, momentum_player2 = 0, 0
    correct_predictions = 0
    total_predictions = 0
    loss = 0  # 用于计算交叉熵损失
    momentum_changes_player1 = []  # 存储选手1的动量变化
    momentum_changes_player2 = []  # 存储选手2的动量变化

    for _, row in df.iterrows():
        p1_score = row['p1_score']
        p2_score = row['p2_score']

        # 处理 'AD' 情况
        if p1_score == 'AD':
            p1_score = 45
        elif p2_score == 'AD':
            p2_score = 45

        serve_width = row['serve_width']
        serve_depth = row['serve_depth']
        return_depth = row['return_depth']
        winner_shot_type = row['winner_shot_type']
        p2_net_pt = row['p2_net_pt']
        p2_net_pt_won = row['p2_net_pt_won']
        point_victor = row['point_victor']
        game_victor = row['game_victor']
        set_victor = row['set_victor']
        p1_games = row['p1_games']
        p2_games = row['p2_games']
        server = row['server']
        rally_count = row['rally_count']
        p1_winner = row['p1_winner']
        p1_break_pt = row['p1_break_pt']

        a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r,u, v, w, x, y ,z = params

        # 这里应用动量更新逻辑
        # 计算每个点后的动量
        # 示例：如果 point_victor 是 1，player1 赢得了这个点
        if point_victor == 1:
            momentum_player1 += a
            momentum_changes_player1.append(a)
            momentum_changes_player2.append(0)
        elif point_victor == 2:
            momentum_player2 += b
            momentum_changes_player2.append(b)
            momentum_changes_player1.append(0)
        # 处理发球
        if server == 1:
            momentum_player1 += c
            momentum_changes_player1.append(c)
            momentum_changes_player2.append(0)

        elif server == 2:
            momentum_player2 += d
            momentum_changes_player2.append(d)
            momentum_changes_player1.append(0)
        #处理发球得分
        if server ==1 and rally_count == 0:
            momentum_player1 += e
            momentum_changes_player1.append(e)
            momentum_changes_player2.append(0)

        elif server ==2 and rally_count == 0:
            momentum_player2 += f
            momentum_changes_player2.append(f)
            momentum_changes_player1.append(0)
        # 处理连续两次得分
        if p1_score == '30' and p2_score == '0' and point_victor == 1:
            momentum_player1 += g
            momentum_changes_player1.append(g)
            momentum_changes_player2.append(0)
        elif p1_score == '0' and p2_score == '30' and point_victor == 2:
            momentum_player2 += h
            momentum_changes_player2.append(h)
            momentum_changes_player1.append(0)
        # 处理破发球得分
        if (server == 1 and p1_break_pt == 2):
            momentum_player2 += i
            momentum_changes_player2.append(i)
            momentum_changes_player1.append(0)
        elif (server == 2 and p1_break_pt == 1):
            momentum_player1 += j
            momentum_changes_player1.append(j)
            momentum_changes_player2.append(0)
        # 处理连续两次丢分
        if p1_score == '0' and p2_score == '30' and point_victor == 2:
            momentum_player1 -= k
            momentum_changes_player1.append(k)
            momentum_changes_player2.append(0)
        elif p1_score == '30' and p2_score == '0' and point_victor == 1:
            momentum_player2 -= l
            momentum_changes_player2.append(l)
            momentum_changes_player1.append(0)
        # 处理丢失赛点球或局点球
        if p1_score == 45 and p2_score == '40':
            momentum_player1 += m
            momentum_changes_player1.append(m)
            momentum_changes_player2.append(0)
        elif p1_score == '40' and p2_score == 45:     # 注意 'AD' 已被转换为 45
            momentum_player2 += n
            momentum_changes_player2.append(n)
            momentum_changes_player1.append(0)
        # 处理发球失误
        if server == 1 and (serve_width != 'BW' or serve_depth != 'CTL'):
            momentum_player1 -= o
            momentum_changes_player1.append(o)
            momentum_changes_player2.append(0)
        elif server == 2 and (serve_width != 'BW' or serve_depth != 'CTL'):
            momentum_player2 -= p
            momentum_changes_player2.append(p)
            momentum_changes_player1.append(0)
        # 考虑球员习惯对得分击球数较多时的影响
        if p1_winner == 1:
            momentum_player1 += q
            momentum_changes_player1.append(q)
            momentum_changes_player2.append(0)
        elif p1_winner == 2:
            momentum_player2 += r
            momentum_changes_player2.append(r)
            momentum_changes_player1.append(0)
        if p2_net_pt == 1 and p2_net_pt_won == 1:
            momentum_player1 += u
            momentum_changes_player1.append(u)
            momentum_changes_player2.append(0)
        if p2_net_pt == 1 and p2_net_pt_won == 0:
            momentum_player2 += v   #一方定位于球网附近时
            momentum_changes_player2.append(v)
            momentum_changes_player1.append(0)
        # 考虑分差和盘数差较大时的影响
        if int(p1_score) - int(p2_score) >= 2 or int(p1_games) - int(p2_games) >= 2:
            momentum_player1 += w
            momentum_changes_player1.append(w)
            momentum_changes_player2.append(0)
        elif int(p2_score) - int(p1_score) >= 2 or int(p2_games) - int(p1_games) >= 2:
            momentum_player2 += x
            momentum_changes_player2.append(x)
            momentum_changes_player1.append(0)
        # 如果比分追平
        if p1_score == p2_score and point_victor == 1:
            momentum_player1 += y
            momentum_changes_player1.append(y)
            momentum_changes_player2.append(0)
        elif p1_score == p2_score and point_victor == 2:
            momentum_player2 += z
            momentum_changes_player2.append(z)
            momentum_changes_player1.append(0)
        # 计算概率并计算交叉熵损失
        momentum_sum = abs(momentum_player1) + abs(momentum_player2)
        if momentum_sum > 0:  # 防止除以0
            p1_prob = abs(momentum_player1) / momentum_sum
            p2_prob = abs(momentum_player2) / momentum_sum

            # 计算交叉熵损失
            if point_victor == 1:
                loss -= np.log(p1_prob)
            elif point_victor == 2:
                epsilon = 1e-10  # 一个小常数
                p2_prob = np.clip(p2_prob, epsilon, 1. - epsilon)  # 将概率限制在[epsilon, 1-epsilon]之间
                loss -= np.log(p2_prob)

        # 计算预测准确率
        if p1_prob > p2_prob:
            predicted_winner = 1
        else:
            predicted_winner = 2

        if predicted_winner == row['point_victor']:
            correct_predictions += 1
        total_predictions += 1

    # 返回准确率作为适应度值和交叉熵损失
    accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
    return accuracy, loss,momentum_changes_player1, momentum_changes_player2

# 示例参数使用
population_size = 100
parameters_population = [np.random.rand(24) for _ in range(population_size)]

# 遗传算法参数
generations = 5
selection_rate = 0.1
mutation_rate = 0.05

best_fitness_scores = []
best_losses = []

for generation in range(generations):
    fitness_results = [fitness_function(params) for params in parameters_population]
    fitness_scores = [result[0] for result in fitness_results]
    losses = [result[1] for result in fitness_results]

    # 选择
    selected_indices = np.argsort(fitness_scores)[-int(selection_rate * population_size):]
    selected_population = [np.array(parameters_population)[i] for i in selected_indices]

    best_fitness_scores.append(max(fitness_scores))
    best_losses.append(min(losses))

    # 交叉和变异
    new_population = []
    while len(new_population) < population_size:
        parent1, parent2 = random.sample(selected_population, 2)
        crossover_point = random.randint(1, len(parent1) - 1)
        child1 = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
        child2 = np.concatenate([parent2[:crossover_point], parent1[crossover_point:]])

        # 变异
        for child in [child1, child2]:
            if random.random() < mutation_rate:
                mutate_index = random.randint(0, len(child) - 1)
                child[mutate_index] = np.random.rand()

        new_population.extend([child1, child2])

    parameters_population = new_population  # 更新种群

# 输出最优解
best_index = np.argmax(best_fitness_scores)
best_parameters = parameters_population[best_index]
final_accuracy, final_loss, momentum_changes_player1, momentum_changes_player2 = fitness_function(best_parameters)
print("Best Parameters:", best_parameters)
print("Final Accuracy:", final_accuracy)
print("Final Loss:", final_loss)

# 绘制适应度图像
plt.figure(figsize=(12, 5))
plt.plot([float(score) for score in best_fitness_scores])
plt.xlabel('Generation')
plt.ylabel('Best Fitness Score')
plt.title('Best Fitness Score vs. Generation')
plt.savefig('best_fitness.pdf', format='pdf')
plt.show()

# 绘制损失图像并保存为 best_loss.pdf
plt.figure(figsize=(12, 5))
plt.plot([float(loss) for loss in best_losses])
plt.xlabel('Generation')
plt.ylabel('Best Loss')
plt.title('Best Loss vs. Generation')
plt.savefig('best_loss.pdf', format='pdf')
plt.show()

# 生成动量变化图并保存为 momentum_change.pdf
plt.figure(figsize=(12, 5))
plt.plot(momentum_changes_player1, label='Player 1')
plt.plot(momentum_changes_player2, label='Player 2')
plt.xlabel('Point')
plt.ylabel('Momentum Change')
plt.legend()
plt.title('Momentum Change Over Points')
plt.savefig('momentum_change.pdf', format='pdf')
plt.show()

# 计算动量差值变化
momentum_diff = np.array(momentum_changes_player1) - np.array(momentum_changes_player2)
momentum_changes_data_player1 = pd.DataFrame({'Momentum Change Player 1': momentum_changes_player1})
momentum_changes_data_player2 = pd.DataFrame({'Momentum Change Player 2': momentum_changes_player2})

momentum_changes_data_player1.to_csv('momentum_changes_player1.csv', index=False)
momentum_changes_data_player2.to_csv('momentum_changes_player2.csv', index=False)
# 生成动量差值变化图并保存为 momentum_difference.pdf
plt.figure(figsize=(12, 5))
plt.plot(momentum_diff, label='Player 1 - Player 2')
plt.xlabel('Point')
plt.ylabel('Momentum Difference')
plt.legend()
plt.title('Momentum Difference Over Points')
plt.savefig('momentum_difference.pdf', format='pdf')
plt.show()
