# 导入所需的库
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 加载数据
wimbledon_matches_path = 'C:\\Users\shuoz\Desktop\美赛c/data_dictionary.csv'
wimbledon_matches = pd.read_csv(wimbledon_matches_path)

# 将分类变量转换为数值型变量
# 为serve_width、serve_depth和return_depth定义映射
serve_width_mapping = {'W': 1, 'BW': 2, 'BC': 3, 'B': 4, 'C': 5}
serve_depth_mapping = {'NCTL': 1, 'CTL': 2}
return_depth_mapping = {'ND': 1, 'D': 2, }  # 包含NaN值的处理

# 应用映射
wimbledon_matches['serve_width_val'] = wimbledon_matches['serve_width'].map(serve_width_mapping)
wimbledon_matches['serve_depth_val'] = wimbledon_matches['serve_depth'].map(serve_depth_mapping)
wimbledon_matches['return_depth_val'] = wimbledon_matches['return_depth'].map(return_depth_mapping).fillna(0)  # 处理NaN值

# 转换得分列中的字母为数值（例如，处理AD等）
score_mapping = {'0': 0, '15': 1, '30': 2, '40': 3, 'AD': 4}
wimbledon_matches['p1_score_val'] = wimbledon_matches['p1_score'].map(lambda x: score_mapping.get(x, x)).astype(int)
wimbledon_matches['p2_score_val'] = wimbledon_matches['p2_score'].map(lambda x: score_mapping.get(x, x)).astype(int)

# 选择数值型变量进行相关性分析
numeric_columns = ['set_no', 'game_no', 'point_no', 'p1_sets', 'p2_sets', 'p1_games', 'p2_games', 'p1_score_val', 'p2_score_val', 'serve_width_val', 'serve_depth_val', 'return_depth_val', 'p1_distance_run', 'p2_distance_run', 'rally_count', 'speed_mph']
numeric_data = wimbledon_matches[numeric_columns]

# 计算相关性矩阵
correlation_matrix = numeric_data.corr()

# 绘制相关性矩阵的热图
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Wimbledon Matches Data')
plt.show()
