import pandas as pd
import matplotlib.pyplot as plt
# 加载数据
df = pd.read_csv('C:\\Users\shuoz\Desktop/Wimbledon_featured_matches.csv')
# 定义动量动态指标函数
def calculate_momentum(df):
    df['p1_momentum'] = 0
    df['p2_momentum'] = 0
    last_point_winner = None

    for i, row in df.iterrows():
        momentum_change = 1
        current_point_winner = 'p1' if row['point_victor'] == 1 else 'p2'

        if row['server'] == row['point_victor']:
            momentum_change = 1
        else:
            momentum_change = 3

        if last_point_winner == current_point_winner:
            momentum_change += 1

        if current_point_winner == 'p1':
            df.loc[i, 'p1_momentum'] += momentum_change
            df.loc[i, 'p2_momentum'] -= momentum_change
        else:
            df.loc[i, 'p1_momentum'] -= momentum_change
            df.loc[i, 'p2_momentum'] += momentum_change

        last_point_winner = current_point_winner

    return df


# 计算动量
momentum_df = calculate_momentum(df)

# 计算每局的动量总和
momentum_sums = momentum_df.groupby('game_no').agg({'p1_momentum': 'sum', 'p2_momentum': 'sum'}).reset_index()

# 计算胜率
momentum_sums['p1_win_probability'] = momentum_sums['p1_momentum'] / (
            momentum_sums['p1_momentum'] + momentum_sums['p2_momentum'])
momentum_sums['p2_win_probability'] = momentum_sums['p2_momentum'] / (
            momentum_sums['p1_momentum'] + momentum_sums['p2_momentum'])

# 初始化预测正确的计数器
correct_predictions = 0
total_predictions = 0

for i in range(1, len(momentum_sums)):
    current_game = momentum_sums.iloc[i - 1]
    next_game = momentum_sums.iloc[i]

    predicted_winner = 'p1' if current_game['p1_win_probability'] > current_game['p2_win_probability'] else 'p2'
    actual_winner = 'p1' if next_game['p1_momentum'] > next_game['p2_momentum'] else 'p2'

    if predicted_winner == actual_winner:
        correct_predictions += 1
    total_predictions += 1

# 计算预测正确率
accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0

print(f'预测正确率: {accuracy * 100:.2f}%')
