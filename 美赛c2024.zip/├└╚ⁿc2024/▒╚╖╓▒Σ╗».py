import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# 路径读取
file_path = 'C:\\Users\shuoz\Desktop/Wimbledon_featured_matches.csv'

# 加载数据
data = pd.read_csv(file_path)


# 转换得分为数值，特殊处理"AD"
def score_to_numeric(score):
    return 45 if score == 'AD' else int(score)


data['p1_score_numeric'] = data['p1_score'].apply(score_to_numeric)
data['p2_score_numeric'] = data['p2_score'].apply(score_to_numeric)


# 计算分差，包括正负值
def calculate_signed_score_difference(row):
    p1_score, p2_score = row['p1_score_numeric'], row['p2_score_numeric']
    raw_diff = p1_score - p2_score
    diff = abs(raw_diff)

    if p1_score < 10 and p2_score < 10:
        return raw_diff
    elif p1_score != 45 and p2_score != 45:
        if 5 <= diff <= 15:
            return 1 if raw_diff > 0 else -1
        elif 15 < diff < 40:
            return 2 if raw_diff > 0 else -2
        elif diff == 40:
            return 3 if raw_diff > 0 else -3
    elif (p1_score == 45 or p2_score == 45) and 5 <= diff < 15:
        return 1 if raw_diff > 0 else -1
    elif (p1_score == 45 or p2_score == 45) and diff == 15:
        return 2 if raw_diff > 0 else -2

    return 0


data['signed_score_difference'] = data.apply(calculate_signed_score_difference, axis=1)

# 保存处理后的数据到CSV
csv_output_path = 'C:\\Users\shuoz\Desktop/pdf/score_differences.csv'
data.to_csv(csv_output_path, index=False)

# 绘制图像并保存为PDF
pdf_output_path = 'C:\\Users\shuoz\Desktop/pdf/score_differences_all_matches.pdf'
with PdfPages(pdf_output_path) as pdf:
    unique_matches = data['match_id'].unique()[:31]  # 示例: 只选取前三场比赛
    for match_id in unique_matches:
        match_data = data[data['match_id'] == match_id]

        plt.figure(figsize=(10, 6))
        plt.plot(match_data['point_no'], match_data['signed_score_difference'], marker='o')
        plt.title(f'Score Difference per Serve - Match ID: {match_id}')
        plt.xlabel('Point Number')
        plt.ylabel('Signed Score Difference')
        plt.axhline(0, color='grey', lw=0.5)
        plt.tight_layout()
        pdf.savefig()
        plt.close()

print(f'Data saved to CSV: {csv_output_path}')
print(f'Graphs saved to PDF: {pdf_output_path}')
