import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from datetime import timedelta

# Load data
file_path = 'C:\\Users\shuoz\Desktop/Wimbledon_featured_matches.csv'
data = pd.read_csv(file_path)

# Convert elapsed_time to seconds
data['elapsed_seconds'] = data['elapsed_time'].apply(lambda x: sum(int(a) * 60**index for index, a in enumerate(reversed(x.split(':')))))

# Calculate start and end times of each set
set_start_end_times = data.groupby(['match_id', 'set_no'])['elapsed_seconds'].agg(['min', 'max']).reset_index()

# Calculate total distance run per set
total_distance_per_set = data.groupby(['match_id', 'set_no']).agg({'p1_distance_run': 'sum', 'p2_distance_run': 'sum'}).reset_index()

# Merge to get all required data together
set_data = pd.merge(set_start_end_times, total_distance_per_set, on=['match_id', 'set_no'])

# Calculate speeds
set_data['p1_speed_mps'] = set_data['p1_distance_run'] / (set_data['max'] - set_data['min'])
set_data['p2_speed_mps'] = set_data['p2_distance_run'] / (set_data['max'] - set_data['min'])

# Extracting player names for the labels
player_names = data[['match_id', 'player1', 'player2']].drop_duplicates().set_index('match_id')

# Plotting and saving to PDF
output_pdf_path = 'C:\\Users\shuoz\Desktop\pdf/player_movement_speed_per_set.pdf'
with PdfPages(output_pdf_path) as pdf:
    for match_id, group in set_data.groupby('match_id'):
        plt.figure(figsize=(10, 6))
        player1, player2 = player_names.loc[match_id]
        plt.plot(group['set_no'], group['p1_speed_mps'], marker='o', label=f'{player1}')
        plt.plot(group['set_no'], group['p2_speed_mps'], marker='x', label=f'{player2}')
        plt.xlabel('Set Number')
        plt.ylabel('Speed (m/s)')
        plt.title(f'Movement Speed per Set - {player1} vs. {player2}')
        plt.legend()
        plt.tight_layout()
        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()

# Save the speed data to CSV
output_csv_path = 'C:\\Users\shuoz\Desktop\pdf/set_speeds.csv'
set_data.to_csv(output_csv_path, index=False)

output_pdf_path, output_csv_path
