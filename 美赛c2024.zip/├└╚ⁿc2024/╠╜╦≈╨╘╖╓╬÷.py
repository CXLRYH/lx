import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置matplotlib和seaborn的样式
plt.style.use('seaborn-darkgrid')
sns.set_context('notebook')

# 加载数据
data_dictionary_path = 'C:\\Users\shuoz\Desktop\美赛c/data_dictionary.csv'
wimbledon_matches_path = 'C:\\Users\shuoz\Desktop\美赛c/Wimbledon_featured_matches.csv'

data_dictionary = pd.read_csv(data_dictionary_path)
wimbledon_matches = pd.read_csv(wimbledon_matches_path)

# 比赛概览：参赛球员和比赛数量
players = pd.concat([wimbledon_matches['player1'], wimbledon_matches['player2']]).unique()
matches = wimbledon_matches['match_id'].unique()

# 发球分析：发球速度分布
serve_speeds = wimbledon_matches[['speed_mph']].dropna()

# 得分点分析：Ace和双误
aces_double_faults = wimbledon_matches[['p1_ace', 'p2_ace', 'p1_double_fault', 'p2_double_fault']].sum()

# 绘制发球速度分布图
plt.figure(figsize=(10, 6))
sns.histplot(serve_speeds['speed_mph'], bins=30, kde=True, color='blue')
plt.title('Serve Speed Distribution')
plt.xlabel('Speed (mph)')
plt.ylabel('Frequency')
plt.savefig('Speed (mph)', format='pdf')
plt.show()

# 绘制Ace和双误总数
aces_double_faults.plot(kind='bar', figsize=(10, 6), color=['green', 'red', 'blue', 'orange'])
plt.title('Aces and Double Faults')
plt.ylabel('Count')
plt.xlabel('Point Type')
plt.xticks(rotation=0)
plt.savefig('Aces and Double Faults', format='pdf')
plt.show()
