import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# 加载数据集
wimbledon_matches = pd.read_csv('C:\\Users\shuoz\Desktop\美赛c/Wimbledon_featured_matches.csv')

# 移除 'match_id', 'player1', 'player2'
features_to_exclude = ['match_id', 'player1', 'player2']
wimbledon_data_for_analysis = wimbledon_matches.drop(columns=features_to_exclude)

# 对分类变量进行独热编码
wimbledon_encoded = pd.get_dummies(wimbledon_data_for_analysis)

# 计算相关系数矩阵
correlation_matrix = wimbledon_encoded.corr()

# 绘制相关系数热力图
plt.figure(figsize=(20, 18))
heatmap = sns.heatmap(correlation_matrix, annot=False, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Wimbledon Matches')

# 保存热力图和相关系数表格到PDF
pdf_path = 'C:\\Users\shuoz\Desktop\美赛c'
with PdfPages(pdf_path) as pdf:
    # 保存热力图
    pdf.savefig(heatmap.figure)
    plt.close()

    # 保存相关系数表格为PDF
    # 因为直接将大型DataFrame保存为PDF可能不实用，我们将其转换为文本文件
    correlation_matrix.to_csv('C:\\Users\shuoz\Desktop\美赛c')

print(f"Analysis saved as PDF at {pdf_path}")
print("Correlation matrix saved as CSV at /mnt/data/wimbledon_correlation_matrix.csv")
