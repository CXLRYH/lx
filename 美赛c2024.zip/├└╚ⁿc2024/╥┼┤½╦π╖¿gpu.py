import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random
import torch
import torch.nn as nn
import torch.optim as optim

# 读取数据
file_path = 'C:\\Users\shuoz\Desktop/Wimbledon_featured_matches.csv'
df = pd.read_csv(file_path)

# 将字母列转换为数值变量的映射字典
serve_width_mapping = {'B': 1, 'BC': 2, 'BW': 3, 'C': 4, 'W': 5}
serve_depth_mapping = {'CTL': 1, 'NCTL': 2}
return_depth_mapping = {'D': 1, 'ND': 2}
winner_shot_type_mapping = {'F': 1, 'B': 2}

# 使用映射字典将字母列转换为数值变量
df['serve_width'] = df['serve_width'].map(serve_width_mapping)
df['serve_depth'] = df['serve_depth'].map(serve_depth_mapping)
df['return_depth'] = df['return_depth'].map(return_depth_mapping)
df['winner_shot_type'] = df['winner_shot_type'].map(winner_shot_type_mapping)

# 定义适应度函数
class TennisPredictor(nn.Module):
    def __init__(self):
        super(TennisPredictor, self).__init__()
        self.fc1 = nn.Linear(13, 24)  # 输入维度为24，输出维度为32
        self.fc2 = nn.Linear(24, 1)   # 输出维度为1，表示概率

    def forward(self, x):
        x = torch.sigmoid(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        return x

def fitness_function(params):
    global df  # 使用全局数据框架
    correct_predictions = 0
    total_predictions = 0

    # 创建模型实例并将其移动到GPU上
    model = TennisPredictor().to(device)

    # 交叉熵损失函数
    criterion = nn.BCELoss()

    optimizer = optim.SGD(model.parameters(), lr=0.01)

    for _, row in df.iterrows():
        features = row[['p1_score', 'p2_score', 'serve_width', 'serve_depth', 'return_depth', 'winner_shot_type',
                        'p2_net_pt', 'p2_net_pt_won', 'point_victor', 'game_victor', 'set_victor',
                        'p1_games', 'p2_games']].values.astype(np.float32)

        # 处理 'AD' 情况
        features[0] = 45 if features[0] == 'AD' else float(features[0])
        features[1] = 45 if features[1] == 'AD' else float(features[1])

        # 将特征转换为PyTorch张量并将其移动到GPU上
        features_tensor = torch.tensor(features, dtype=torch.float32, device=device)

        # 使用模型进行预测
        output = model(features_tensor)
        predicted_winner = 1 if output.item() > 0.5 else 2

        # 计算交叉熵损失
        target = torch.tensor([1.0 if row['point_victor'] == 1 else 0.0], dtype=torch.float32, device=device)
        loss = criterion(output, target)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # 统计正确预测
        if predicted_winner == row['point_victor']:
            correct_predictions += 1
        total_predictions += 1

    # 计算预测准确率
    accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0

    # 返回交叉熵损失作为适应度值
    return accuracy

# 示例参数使用
population_size = 10
parameters_population = [np.random.rand(24) for _ in range(population_size)]

# 遗传算法参数
generations = 50
selection_rate = 0.2
mutation_rate = 0.1

best_fitness_scores = []

# 指定在GPU上进行计算
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

for generation in range(generations):
    fitness_scores = [fitness_function(params) for params in parameters_population]

    # 选择
    selected_indices = np.argsort(fitness_scores)[-int(selection_rate * population_size):]
    selected_population = [np.array(parameters_population)[i] for i in selected_indices]

    best_fitness_scores.append(max(fitness_scores))

    # 交叉和变异
    new_population = []
    while len(new_population) < population_size:
        parent1, parent2 = random.sample(selected_population, 2)
        crossover_point = random.randint(1, len(parent1) - 1)
        child1 = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
        child2 = np.concatenate([parent2[:crossover_point], parent1[crossover_point:]])

        # 变异
        for child in [child1, child2]:
            if random.random() < mutation_rate:
                mutate_index = random.randint(0, len(child) - 1)
                child[mutate_index] = np.random.rand()

        new_population.extend([child1, child2])

    parameters_population = new_population  # 更新种群

# 输出最优解
best_parameters = parameters_population[np.argmax([fitness_function(params) for params in parameters_population])]
print("Best Parameters:", best_parameters)

plt.plot([float(score) for score in best_fitness_scores])
plt.xlabel('Generation')
plt.ylabel('Best Fitness Score')
plt.title('Best Fitness Score vs. Generation')

# 输出最终的准确率
final_accuracy = fitness_function(best_parameters)
print("Final Accuracy:", final_accuracy)

# 保存图像为PDF文件
plt.savefig('best_fitness_scores.pdf', format='pdf')

# 显示图像
plt.show()
